<footer class="content-footer footer bg-footer-theme">
    <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
        <div class="mb-2 mb-md-0">
            ©
            <script>
                document.write(new Date().getFullYear());
            </script>
            , {{ __('footer.made_by') }}
            <a href="https://github.com/404NotFoundIndonesia" target="_blank" class="footer-link fw-bolder">404 Not Found Indonesia</a>
        </div>
    </div>
</footer>
