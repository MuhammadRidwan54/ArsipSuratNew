<?php

return [
    'profile' => [
        'profile' => 'Profile',
        'settings' => 'Settings',
        'notifications' => 'Notifications',
        'logout' => 'Logout',
        'deactivate_account' => 'Deactivate Account',
        'deactivate_confirm_message' => 'Are you sure you want to deactivate your account?',
        'deactivate_confirm' => 'I confirm my account deactivation'
    ],
    'search' => 'Search...'
];
