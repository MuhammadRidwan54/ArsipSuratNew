<?php

return [
    'made_by' => 'made with 🫶 by',
];
