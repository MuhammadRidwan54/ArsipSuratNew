<?php

return [
    'made_by' => 'dibuat dengan 🫶 oleh',
];
