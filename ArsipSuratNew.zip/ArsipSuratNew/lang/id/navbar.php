<?php

return [
    'profile' => [
        'profile' => 'Profil',
        'settings' => 'Pengaturan',
        'notifications' => 'Notifikasi',
        'logout' => 'Keluar',
        'deactivate_account' => 'Nonaktifkan Akun',
        'deactivate_confirm_message' => 'Apakah Anda yakin ingin menonaktifkan akun Anda?',
        'deactivate_confirm' => 'Saya yakin',
    ],
    'search' => 'Pencarian...'
];
